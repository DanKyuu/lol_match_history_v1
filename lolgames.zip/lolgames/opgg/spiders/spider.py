#Sites com códigos de apoio:
# https://medium.com/datadriveninvestor/how-i-created-a-league-of-legends-high-elo-database-using-scrapy-3becdee8f385
# https://linuxhint.com/scrapy-with-xpath-selectors/

# -*- coding: utf-8 -*-
import scrapy
from scrapy import Request
from ..items import Game
from ..constants import XPATHS_LADDER, XPATHS_GAME
from datetime import date

hoje=date.today()

class OpggSpider(scrapy.Spider):
    name = 'opgg'
    allowed_domains = ['op.gg']
    servers = ['br', 'jp', 'euw', 'oce', 'lan', 'tr', 'www', 'na', 'eune',
               'las', 'ru']
    pag = ['', 'page=2','page=3','page=4','page=5','page=6','page=7','page=8','page=9','page=10']
    list_pag = ['.op.gg/ranking/ladder/'+page for page in pag]
    #start_urls = ['http://' + server + list_pag for server in servers]
    #start_urls = ['http://' + aux_server + aux_list_pag for aux_server, aux_list_pag in zip(servers*len(list_pag), list_pag)]
    start_urls = ['http://' + aux_server + aux_list_pag for aux_server, aux_list_pag in zip(servers, list_pag)]
    

    def _parse_champions(self, selector):
        for champion in selector:
            yield champion.xpath(XPATHS_GAME['_champion_name']).extract_first()

    def _parse_profile_links(self, selector):
        for summoner in selector:
            link = selector.xpath(XPATHS_GAME['profile_link']).extract_first()
            meta = response.meta.copy()
            meta.update({'related': True})
            yield Request(url="http:" + link,
                          callback=self.parse_games, meta=meta)

    def parse(self, response):
        summoners = response.xpath(XPATHS_LADDER['_summoners']).extract()
        for summoner in summoners:
            yield Request(url="http:"+summoner, callback=self.parse_games)
    
    def parse_games(self, response):
        matches = response.xpath(XPATHS_GAME['_matches'])
        for match in matches:
            summoners_t1 = match.xpath(XPATHS_GAME['_summoners_team_1'])
            summoners_t2 = match.xpath(XPATHS_GAME['_summoners_team_2'])
            if not response.meta.get('related'):
                self._parse_profile_links(summoners_t1)
                self._parse_profile_links(summoners_t2)

            match_type = match.xpath(XPATHS_GAME['_match_type']
                                     ).extract_first().strip()
            result = response.xpath(XPATHS_GAME['result']
                                     ).extract_first().strip()
            if match_type != 'Ranked Solo' or result == 'Remake':
                continue

            selector_t1 = match.xpath(XPATHS_GAME['_champions_team_1'])
            selector_t2 = match.xpath(XPATHS_GAME['_champions_team_2'])
            team_1 = list(self._parse_champions(selector_t1))
            team_2 = list(self._parse_champions(selector_t2))

            item = Game()
            result = response.xpath(
                XPATHS_GAME['result']).extract_first().strip()
            player = response.xpath(XPATHS_GAME['player']).extract_first()
            players_t1 = [summoner.xpath(
                          './/text()'
                          ).extract()[1] for summoner in summoners_t1]
            if player in players_t1:
                if result == 'Victory':
                    item['result'] = result
                else:
                    item['result'] = 'Defeat'
            else:
                if result == 'Victory':
                    item['result'] = 'Defeat'
                else:
                    item['result'] = result

            item['server'] = response.url.split('/')[2].split('.')[0]
            item['mmr'] = response.xpath(XPATHS_GAME['rank_name']).extract_first()
            item['team_1'] = team_1
            item['team_2'] = team_2
            item['timestamp'] = match.xpath(XPATHS_GAME['timestamp']).extract_first()
            item['main_player'] = match.xpath(XPATHS_GAME['player']).extract_first()
            item['game_type'] = match.xpath(XPATHS_GAME['game_type']).extract_first()
            item['most_played_champs_season'] = match.xpath(XPATHS_GAME['most_played_champs_season']).extract()
            item['list_champs_win_lose_7d'] = match.xpath(XPATHS_GAME['list_champs_win_lose_7d']).extract()
            item['list_ratio_win_lose_7d'] = ''.join(match.xpath(XPATHS_GAME['list_ratio_win_lose_7d']).extract()).split()
            item['list_summoners_t1'] = match.xpath(XPATHS_GAME['list_summoner_t1']).extract()
            item['list_summoners_t2'] = match.xpath(XPATHS_GAME['list_summoner_t2']).extract()
            item['champ_used'] = match.xpath(XPATHS_GAME['champ_used']).extract()
            #item['data_coleta']= date.today()
            item['_match_length'] = match.xpath(XPATHS_GAME['_match_length']).extract_first()
            
            item['s_spell_1'] = match.xpath(XPATHS_GAME['s_spell_1']).extract()
            item['s_spell_2'] = match.xpath(XPATHS_GAME['s_spell_2']).extract()

            item['rune_main'] = match.xpath(XPATHS_GAME['rune_main']).extract()
            item['rune_sec'] = match.xpath(XPATHS_GAME['rune_sec']).extract()
            yield item