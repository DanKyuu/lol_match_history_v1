# -*- coding: utf-8 -*-
import scrapy
from datetime import date

class Game(scrapy.Item):
    timestamp = scrapy.Field()
    server = scrapy.Field()
    mmr = scrapy.Field()
    result = scrapy.Field()
    team_1 = scrapy.Field()
    team_2 = scrapy.Field()
    
    #NOVOS ATRIBUTOS:
    main_player = scrapy.Field()
    rank_name = scrapy.Field()
    game_type = scrapy.Field()
    most_played_champs_season = scrapy.Field()
    list_champs_win_lose_7d = scrapy.Field()
    list_ratio_win_lose_7d = scrapy.Field()
    list_summoners_t1 = scrapy.Field()
    list_summoners_t2 = scrapy.Field()
    champ_used = scrapy.Field()
    #data_coleta = scrapy.Field()
    _match_length = scrapy.Field()
    rune_main = scrapy.Field()
    rune_sec = scrapy.Field()
    s_spell_1 = scrapy.Field()
    s_spell_2 = scrapy.Field()

    items_bought = scrapy.Field()
    trinket = scrapy.Field()
    kills = scrapy.Field()
    deaths = scrapy.Field()
    assists = scrapy.Field()
    level = scrapy.Field()

    list_played_ranked = scrapy.Field()
    list_KDA_ranked = scrapy.Field()
    list_win_ratio_ranked = scrapy.Field()
    list_number_games_ranked = scrapy.Field()