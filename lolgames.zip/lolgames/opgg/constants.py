XPATHS_GAME = {
    'mmr': '//span[@class="tierRank"]/text()',

    'result': './/div[@class="GameResult"]/text()',
    '_match_type': './/div[@class="GameType"]/text()',
    '_matches': '//div[@class="GameItemWrap"]',


    '_champions_team_1': './/div[@class="Team"][1]//div[@class="ChampionImage"]',
    '_champions_team_2': './/div[@class="Team"][2]//div[@class="ChampionImage"]',
    '_summoners_team_1': './/div[@class="Team"][1]//div[@class="SummonerName"]',
    '_summoners_team_2': './/div[@class="Team"][2]//div[@class="SummonerName"]',
    '_champion_name': './/div/text()',
    'timestamp': './/div[@class="TimeStamp"]//span/text()',
    'profile_link': './/a/@href',
    'player': '//div[@class="Information"]/span//text()',

    #outras métricas consideradas
    #'data_coleta': '',
    'rank_name': '//div[@class="TierRank"]/text()',
    '_match_length': './/div[@class="GameLength"]/text()',
    'game_type': '//div[@class="RankType"]/text()',
    'most_played_champs_season': '//div[@class="ChampionBox Ranked"]//@alt',
    'list_champs_win_lose_7d': '//div[@class="ChampionWinRatioBox"]//div[@class="ChampionName"]/@title',
    'list_ratio_win_lose_7d': '//div[@class="ChampionWinRatioBox"]//div[@class="WinRatio"]/text()',
    
    'list_played_ranked': '//div[@class="ChampionBox Ranked"]//a/img/@alt',
    'list_KDA_ranked': '//div[@class="ChampionBox Ranked"]//span[@class="KDA"]/text()',
    'list_win_ratio_ranked':'normalize-space(//div[@class="ChampionBox Ranked"]//div[@title="Win Ratio"]//text())',
    'list_number_games_ranked':'//div[@class="ChampionBox Ranked"]//div[@class="Played"]//div[@class="Title"]/text()',

    'list_summoner_t1': './/div[@class="FollowPlayers Names"]//div[@class="Team"][1]//div[@class="SummonerName"]//a/text()',
    'list_summoner_t2': './/div[@class="FollowPlayers Names"]//div[@class="Team"][2]//div[@class="SummonerName"]//a/text()',
    'champ_used': './/div[@class="GameSettingInfo"]//div[@class="ChampionName"]/a/text()',

    's_spell_1': './/div[@class="GameSettingInfo"]//div[@class="SummonerSpell"]//div[@class="Spell"][1]/img/@alt',
    's_spell_2': './/div[@class="GameSettingInfo"]//div[@class="SummonerSpell"]//div[@class="Spell"][2]/img/@alt',
    'rune_main': './/div[@class="GameSettingInfo"]//div[@class="Runes"]//div[@class="Rune"][1]//img/@alt',
    'rune_sec':  './/div[@class="GameSettingInfo"]//div[@class="Runes"]//div[@class="Rune"][2]//img/@alt',

    'items_bought':'.//div[@class="ItemList"]/div[@class="Item"]/img/@alt',
    
    'trinket': './/div[@class="Items"]/div[@class="Trinket"]/text()',

    'kills':'.//div[@class="KDA"]/span[@class="Kill"]/text()',
    'deaths':'.//div[@class="KDA"]/span[@class="Death"]/text()',
    'assists':'.//div[@class="KDA"]/span[@class="Assist"]/text()',

    'level':'.//div[@class="Stats"]//div[@class="Level"]/text()'
}


XPATHS_LADDER = {
    '_summoners': '//a[not(contains(@class, "ranking-highest__name"))]//@href[contains(.,"userName")]'
}

#caminho para champ do summoner da página:
#response.xpath('.//div[@class="GameItemWrap"]//div[@class="Content"]//div[@class="GameSettingInfo"]//div[@class="ChampionImage"]//@alt').extract()
#caminho para pegar os items usados pelo jogador titular na partida:
#response.xpath('//div[@class="GameItemWrap"]//div[@class="Item"]/img/@alt').extract()
#caminho para extrair índice de vitórias com champions jogados:
#''.join(response.xpath('//div[@class="ChampionWinRatioBox"]//div[@class="WinRatio"]/text()').extract()).split()

#chamando o spider:
#scrapy crawl opgg -o games_sec.csv